#pragma once
#include <iostream>
#include "Renderer.h"

class Object
{
	enum  statusType
	{
		building =0, 
		obstacle,
		cannon,
		bullet
	};
	int status;
	int x, y;

public:
	Object() {
		status = statusType::building;
		x = 0;
		y = 0;
	};
};
